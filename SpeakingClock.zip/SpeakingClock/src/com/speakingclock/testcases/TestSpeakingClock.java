package com.speakingclock.testcases;

import com.speakingclock.SpeakingClock;
import static org.junit.Assert.*;  
import org.junit.Test;  

public class TestSpeakingClock {
 
 
 @Test
 public  void testTime()
 {
	 assertEquals(SpeakingClock.printWords(10, 12),"twelve minutes past ten");
	 assertEquals(SpeakingClock.printWords(12, 0),"its midday");
	 assertEquals(SpeakingClock.printWords(24, 0),"its midnight");
 }

}
